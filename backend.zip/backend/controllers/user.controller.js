const mongoose = require("mongoose");
const User = require("../models/user.model");
const Resignation = require("../models/resignation.model");
const Responses = require("../models/responses.model");
const submitResignation = async (req, res) => {
  const { lwd } = req.body;
  if (!lwd) res.status(400).json({ message: "Last Working day is required" });
  try {
    const resignation = await Resignation.create({
      employeeId: req.user._id,
      lwd,
    });
    res.status(200).json({
      data: {
        resignation: {
          _id: resignation._id,
        },
      },
    });
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

const submitResponses = async (req, res) => {
  const { responses } = req.body;
  try {
    await Responses.create({
      employeeId: req.user._id,
      responses,
    });
    res.status(200).json({ message: "Responses submitted succesfully" });
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};
module.exports = { submitResignation, submitResponses };
